const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');
const db = require('../config/db');

exports.signup = [
  body('username').notEmpty(),
  body('displayName').notEmpty(),
  body('email').isEmail(),
  body('password').isLength({ min: 6 }),
  body('isStudent').isBoolean(),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, displayName, email, password, isStudent } = req.body;
    const role = isStudent ? 'student' : 'agent';

    bcrypt.hash(password, 10, (err, hashedPassword) => {
      if (err) {
        return res.status(500).json({ message: "Error hashing password" });
      }

      const query = "INSERT INTO users (username, displayname, email, password, role) VALUES (?, ?, ?, ?, ?)";
      db.query(query, [username, displayName, email, hashedPassword, role], (err, result) => {
        if (err) {
          return res.status(500).json({ message: err });
        }
        res.status(201).json({ message: "User registered successfully!" });
      });
    });
  }
];